# Smart Tools Hub
Flutter source starter: calculator, unit converter, QR generator preview, text counter/case tools.
Build: `flutter pub get`, `flutter run`, `flutter build appbundle --release`.
Source only; no APK/AAB, ads, privacy policy, or store assets included yet. Test before publishing.
