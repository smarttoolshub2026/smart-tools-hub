import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Smart Tools Hub',
        theme: ThemeData(
          colorSchemeSeed: Colors.teal,
          useMaterial3: true,
          scaffoldBackgroundColor: const Color(0xfff5faf9),
        ),
        home: const Home(),
      );
}

class ToolItem {
  final String name;
  final IconData icon;
  final Widget page;
  const ToolItem(this.name, this.icon, this.page);
}

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    final tools = <ToolItem>[
      ToolItem('Calculator', Icons.calculate, const Calc()),
      ToolItem('Unit Converter', Icons.swap_horiz, const Convert()),
      ToolItem('QR Code Maker', Icons.qr_code, const QRPage()),
      ToolItem('Text Tools', Icons.text_fields, const TextPage()),
      ToolItem('GST Calculator', Icons.receipt_long, const GSTPage()),
      ToolItem('EMI Calculator', Icons.account_balance, const EMIPage()),
      ToolItem('Percentage Calculator', Icons.percent, const PercentPage()),
      ToolItem('Discount Calculator', Icons.sell, const DiscountPage()),
      ToolItem('Age Calculator', Icons.cake, const AgePage()),
      ToolItem('Password Generator', Icons.password, const PasswordPage()),
      ToolItem('Stopwatch', Icons.timer, const StopwatchPage()),
      ToolItem('Countdown Timer', Icons.hourglass_bottom, const CountdownPage()),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Tools Hub', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: false,
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(14),
        itemCount: tools.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.08,
        ),
        itemBuilder: (context, index) {
          final tool = tools[index];
          return Card(
            elevation: 2,
            clipBehavior: Clip.antiAlias,
            child: InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => tool.page),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(tool.icon, size: 42, color: Theme.of(context).colorScheme.primary),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Text(tool.name, textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class Calc extends StatefulWidget {
  const Calc({super.key});
  @override
  State<Calc> createState() => _CalcState();
}
class _CalcState extends State<Calc> {
  final a = TextEditingController(), b = TextEditingController();
  String out = '';
  void run(String op) {
    final x = double.tryParse(a.text), y = double.tryParse(b.text);
    if (x == null || y == null) { setState(() => out = 'Enter valid numbers'); return; }
    if (op == '÷' && y == 0) { setState(() => out = 'Cannot divide by zero'); return; }
    final r = switch (op) { '+' => x + y, '−' => x - y, '×' => x * y, _ => x / y };
    setState(() => out = 'Result: ${fmt(r)}');
  }
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Calculator')),
    body: FormPad(children: [
      numberField(a, 'First number'), numberField(b, 'Second number'),
      Wrap(spacing: 8, children: ['+','−','×','÷'].map((o) =>
        FilledButton(onPressed: () => run(o), child: Text(o))).toList()),
      resultText(out),
    ]),
  );
}

class Convert extends StatefulWidget {
  const Convert({super.key});
  @override
  State<Convert> createState() => _ConvertState();
}
class _ConvertState extends State<Convert> {
  final n = TextEditingController();
  String kind = 'km → m', out = '';
  final options = ['km → m','m → km','m → cm','cm → m','kg → g','g → kg','L → mL','mL → L','°C → °F','°F → °C'];
  double convert(double v) => switch (kind) {
    'km → m' => v * 1000, 'm → km' => v / 1000,
    'm → cm' => v * 100, 'cm → m' => v / 100,
    'kg → g' => v * 1000, 'g → kg' => v / 1000,
    'L → mL' => v * 1000, 'mL → L' => v / 1000,
    '°C → °F' => v * 9 / 5 + 32, _ => (v - 32) * 5 / 9,
  };
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('Unit Converter')),
    body: FormPad(children: [
      DropdownButtonFormField<String>(value: kind, decoration: const InputDecoration(labelText: 'Conversion'),
        items: options.map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
        onChanged: (x) => setState(() { kind = x!; out = ''; })),
      numberField(n, 'Value'),
      FilledButton(onPressed: () { final v = double.tryParse(n.text); setState(() => out = v == null ? 'Enter a valid number' : 'Result: ${fmt(convert(v))}'); }, child: const Text('Convert')),
      resultText(out),
    ]),
  );
}

class QRPage extends StatefulWidget {
  const QRPage({super.key});
  @override
  State<QRPage> createState() => _QRState();
}
class _QRState extends State<QRPage> {
  final t = TextEditingController(); String data = '';
  @override
  Widget build(BuildContext c) => Scaffold(
    appBar: AppBar(title: const Text('QR Code Maker')),
    body: FormPad(children: [
      TextField(controller: t, maxLines: 3, decoration: const InputDecoration(labelText: 'Text or link', border: OutlineInputBorder())),
      FilledButton(onPressed: () => setState(() => data = t.text.trim()), child: const Text('Generate QR')),
      if (data.isNotEmpty) Center(child: QrImageView(data: data, size: 220)),
      if (data.isNotEmpty) OutlinedButton.icon(onPressed: () => Clipboard.setData(ClipboardData(text: data)), icon: const Icon(Icons.copy), label: const Text('Copy text')),
    ]),
  );
}

class TextPage extends StatefulWidget {
  const TextPage({super.key});
  @override
  State<TextPage> createState() => _TextState();
}
class _TextState extends State<TextPage> {
  final t = TextEditingController();
  @override
  Widget build(BuildContext c) {
    final s = t.text;
    final words = s.trim().isEmpty ? 0 : s.trim().split(RegExp(r'\s+')).length;
    return Scaffold(
      appBar: AppBar(title: const Text('Text Tools')),
      body: FormPad(children: [
        TextField(controller: t, maxLines: 6, onChanged: (_) => setState(() {}),
          decoration: const InputDecoration(labelText: 'Enter text', border: OutlineInputBorder())),
        Text('Words: $words     Characters: ${s.length}     Lines: ${s.isEmpty ? 0 : s.split('\n').length}'),
        Wrap(spacing: 8, runSpacing: 8, children: [
          OutlinedButton(onPressed: () => setState(() => t.text = s.toUpperCase()), child: const Text('UPPERCASE')),
          OutlinedButton(onPressed: () => setState(() => t.text = s.toLowerCase()), child: const Text('lowercase')),
          OutlinedButton(onPressed: () => setState(() => t.text = s.trim()), child: const Text('Trim spaces')),
          FilledButton.tonal(onPressed: () => Clipboard.setData(ClipboardData(text: s)), child: const Text('Copy text')),
          TextButton(onPressed: () => setState(() => t.clear()), child: const Text('Clear')),
        ]),
      ]),
    );
  }
}

class GSTPage extends StatefulWidget {
  const GSTPage({super.key});
  @override
  State<GSTPage> createState() => _GSTState();
}
class _GSTState extends State<GSTPage> {
  final amount = TextEditingController(); double rate = 18; bool inclusive = false;
  @override
  Widget build(BuildContext c) {
    final v = double.tryParse(amount.text) ?? 0;
    final base = inclusive ? v / (1 + rate / 100) : v;
    final tax = inclusive ? v - base : v * rate / 100;
    return Scaffold(appBar: AppBar(title: const Text('GST Calculator')),
      body: FormPad(children: [
        numberField(amount, 'Amount (₹)', onChanged: (_) => setState(() {})),
        DropdownButtonFormField<double>(value: rate, decoration: const InputDecoration(labelText: 'GST rate'),
          items: [5.0,12.0,18.0,28.0].map((x) => DropdownMenuItem(value: x, child: Text('${x.toInt()}%'))).toList(),
          onChanged: (x) => setState(() => rate = x!)),
        SwitchListTile(title: const Text('Amount already includes GST'), value: inclusive, onChanged: (x) => setState(() => inclusive = x)),
        resultText('Base amount: ₹${fmt(base)}\nGST: ₹${fmt(tax)}\n${inclusive ? 'Total' : 'Total with GST'}: ₹${fmt(inclusive ? v : v + tax)}'),
      ]));
  }
}

class EMIPage extends StatefulWidget {
  const EMIPage({super.key});
  @override
  State<EMIPage> createState() => _EMIState();
}
class _EMIState extends State<EMIPage> {
  final principal = TextEditingController(text: '100000');
  final rate = TextEditingController(text: '10');
  final years = TextEditingController(text: '5');
  @override
  Widget build(BuildContext c) {
    final p = double.tryParse(principal.text) ?? 0;
    final annual = double.tryParse(rate.text) ?? 0;
    final y = double.tryParse(years.text) ?? 0;
    final months = (y * 12).round();
    final r = annual / 1200;
    final emi = months <= 0 || p <= 0 ? 0.0 : r == 0 ? p / months : p * r * pow(1 + r, months) / (pow(1 + r, months) - 1);
    return Scaffold(appBar: AppBar(title: const Text('EMI Calculator')),
      body: FormPad(children: [
        numberField(principal, 'Loan amount (₹)', onChanged: (_) => setState(() {})),
        numberField(rate, 'Annual interest rate (%)', onChanged: (_) => setState(() {})),
        numberField(years, 'Loan period (years)', onChanged: (_) => setState(() {})),
        resultText('Monthly EMI: ₹${fmt(emi)}\nTotal payment: ₹${fmt(emi * months)}\nTotal interest: ₹${fmt(emi * months - p)}'),
      ]));
  }
}

class PercentPage extends StatefulWidget {
  const PercentPage({super.key});
  @override
  State<PercentPage> createState() => _PercentState();
}
class _PercentState extends State<PercentPage> {
  final part = TextEditingController(), total = TextEditingController();
  @override
  Widget build(BuildContext c) {
    final a = double.tryParse(part.text), b = double.tryParse(total.text);
    final value = a == null || b == null || b == 0 ? null : a / b * 100;
    return Scaffold(appBar: AppBar(title: const Text('Percentage Calculator')),
      body: FormPad(children: [
        numberField(part, 'Value', onChanged: (_) => setState(() {})), numberField(total, 'Total', onChanged: (_) => setState(() {})),
        resultText(value == null ? 'Enter valid values (total cannot be zero)' : 'Percentage: ${fmt(value)}%'),
      ]));
  }
}

class DiscountPage extends StatefulWidget {
  const DiscountPage({super.key});
  @override
  State<DiscountPage> createState() => _DiscountState();
}
class _DiscountState extends State<DiscountPage> {
  final price = TextEditingController(), discount = TextEditingController();
  @override
  Widget build(BuildContext c) {
    final p = double.tryParse(price.text), d = double.tryParse(discount.text);
    final saved = p == null || d == null ? null : p * d / 100;
    return Scaffold(appBar: AppBar(title: const Text('Discount Calculator')),
      body: FormPad(children: [
        numberField(price, 'Original price (₹)', onChanged: (_) => setState(() {})), numberField(discount, 'Discount (%)', onChanged: (_) => setState(() {})),
        resultText(saved == null ? 'Enter price and discount' : 'You save: ₹${fmt(saved)}\nFinal price: ₹${fmt(p! - saved)}'),
      ]));
  }
}

class AgePage extends StatefulWidget {
  const AgePage({super.key});
  @override
  State<AgePage> createState() => _AgeState();
}
class _AgeState extends State<AgePage> {
  DateTime? birth; String age = '';
  @override
  Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Age Calculator')),
    body: FormPad(children: [
      FilledButton.icon(onPressed: () async {
        final d = await showDatePicker(context: c, initialDate: DateTime(2000), firstDate: DateTime(1900), lastDate: DateTime.now());
        if (d != null) setState(() { birth = d; final now = DateTime.now(); int y = now.year - d.year; int m = now.month - d.month; int days = now.day - d.day; if (days < 0) { m--; days += DateTime(now.year, now.month, 0).day; } if (m < 0) { y--; m += 12; } age = '$y years, $m months, $days days'; });
      }, icon: const Icon(Icons.calendar_month), label: const Text('Select date of birth')),
      if (birth != null) resultText('Date of birth: ${birth!.day}/${birth!.month}/${birth!.year}\nAge: $age'),
    ]));
}

class PasswordPage extends StatefulWidget {
  const PasswordPage({super.key});
  @override
  State<PasswordPage> createState() => _PasswordState();
}
class _PasswordState extends State<PasswordPage> {
  int length = 16; bool symbols = true, numbers = true; String password = '';
  void generate() {
    const letters = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ';
    const nums = '23456789'; const syms = '!@#\$%&*_-+?';
    final chars = letters + (numbers ? nums : '') + (symbols ? syms : '');
    final random = Random.secure();
    setState(() => password = List.generate(length, (_) => chars[random.nextInt(chars.length)]).join());
  }
  @override
  Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Password Generator')),
    body: FormPad(children: [
      Text('Password length: $length'),
      Slider(value: length.toDouble(), min: 8, max: 32, divisions: 24, label: '$length', onChanged: (v) => setState(() => length = v.round())),
      SwitchListTile(title: const Text('Include numbers'), value: numbers, onChanged: (v) => setState(() => numbers = v)),
      SwitchListTile(title: const Text('Include symbols'), value: symbols, onChanged: (v) => setState(() => symbols = v)),
      FilledButton(onPressed: generate, child: const Text('Generate password')),
      if (password.isNotEmpty) SelectableText(password, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      if (password.isNotEmpty) OutlinedButton.icon(onPressed: () => Clipboard.setData(ClipboardData(text: password)), icon: const Icon(Icons.copy), label: const Text('Copy password')),
    ]));
}

class StopwatchPage extends StatefulWidget {
  const StopwatchPage({super.key});
  @override
  State<StopwatchPage> createState() => _StopwatchState();
}
class _StopwatchState extends State<StopwatchPage> {
  final watch = Stopwatch(); Timer? ticker;
  void start() { watch.start(); ticker ??= Timer.periodic(const Duration(milliseconds: 100), (_) { if (mounted) setState(() {}); }); setState(() {}); }
  void stop() { watch.stop(); setState(() {}); }
  void reset() { watch.reset(); setState(() {}); }
  String get display { final d = watch.elapsed; return '${d.inMinutes.toString().padLeft(2,'0')}:${(d.inSeconds % 60).toString().padLeft(2,'0')}.${(d.inMilliseconds % 1000 ~/ 10).toString().padLeft(2,'0')}'; }
  @override
  void dispose() { ticker?.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Stopwatch')),
    body: FormPad(children: [
      Center(child: Text(display, style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold))),
      Wrap(alignment: WrapAlignment.center, spacing: 10, children: [
        FilledButton(onPressed: watch.isRunning ? null : start, child: const Text('Start')),
        FilledButton.tonal(onPressed: watch.isRunning ? stop : null, child: const Text('Stop')),
        OutlinedButton(onPressed: reset, child: const Text('Reset')),
      ]),
    ]));
}

class CountdownPage extends StatefulWidget {
  const CountdownPage({super.key});
  @override
  State<CountdownPage> createState() => _CountdownState();
}
class _CountdownState extends State<CountdownPage> {
  final mins = TextEditingController(text: '1');
  Timer? timer; int remaining = 0; bool running = false;
  void start() {
    final m = int.tryParse(mins.text);
    if (m == null || m < 1 || m > 1440) { setState(() => remaining = 0); return; }
    timer?.cancel(); setState(() { remaining = m * 60; running = true; });
    timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (remaining <= 1) { t.cancel(); if (mounted) setState(() { remaining = 0; running = false; }); }
      else if (mounted) setState(() => remaining--);
    });
  }
  @override
  void dispose() { timer?.cancel(); mins.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Countdown Timer')),
    body: FormPad(children: [
      numberField(mins, 'Minutes (1 to 1440)'),
      Center(child: Text('${(remaining ~/ 60).toString().padLeft(2,'0')}:${(remaining % 60).toString().padLeft(2,'0')}', style: const TextStyle(fontSize: 48, fontWeight: FontWeight.bold))),
      Wrap(spacing: 10, children: [
        FilledButton(onPressed: running ? null : start, child: const Text('Start')),
        OutlinedButton(onPressed: () { timer?.cancel(); setState(() { running = false; remaining = 0; }); }, child: const Text('Reset')),
      ]),
    ]));
}

class FormPad extends StatelessWidget {
  final List<Widget> children;
  const FormPad({super.key, required this.children});
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    padding: const EdgeInsets.all(16),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      for (final child in children) Padding(padding: const EdgeInsets.only(bottom: 14), child: child),
    ]),
  );
}

Widget numberField(TextEditingController controller, String label, {ValueChanged<String>? onChanged}) =>
  TextField(controller: controller, keyboardType: const TextInputType.numberWithOptions(decimal: true),
    onChanged: onChanged, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()));

Widget resultText(String text) => Container(
  width: double.infinity, padding: const EdgeInsets.all(14),
  decoration: BoxDecoration(color: Colors.teal.withValues(alpha: 0.08), borderRadius: BorderRadius.circular(12)),
  child: SelectableText(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
);

String fmt(num n) => n.toStringAsFixed(2);
