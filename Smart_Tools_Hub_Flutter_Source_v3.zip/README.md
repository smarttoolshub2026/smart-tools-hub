# Smart Tools Hub

Flutter source for Smart Tools Hub.

## Build
Run `flutter pub get`, then `flutter build apk --release`.
